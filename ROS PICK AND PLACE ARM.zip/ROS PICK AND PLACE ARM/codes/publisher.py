import rospy
from std_msgs.msg import String
from sensor_msgs.msg import JointState
import math

pub = rospy.Publisher('/joint_positions_string', String, queue_size=10)

def joint_state_callback(msg):
    # Convert position from radians to degrees and round to the nearest integer
    degrees_positions = [str(int(round(pos * (180 / math.pi)))) for pos in msg.position]
    degrees_positions[2]= str(-1* int(degrees_positions[2]))
    
    # Join the list of integer degree values into a single string separated by commas
    degrees_positions_str = ",".join(degrees_positions)
    
    rospy.loginfo("Joined Joint Positions in Degrees (Integer): %s", degrees_positions_str)

    # Create and publish the String message
    new_msg = String()
    new_msg.data = degrees_positions_str
    pub.publish(new_msg)

def listener():
    rospy.init_node('joint_state_listener', anonymous=True)
    rospy.Subscriber('/joint_states', JointState, joint_state_callback)
    rospy.spin()

if __name__ == '__main__':
    try:
        listener()
    except rospy.ROSInterruptException:
        pass
