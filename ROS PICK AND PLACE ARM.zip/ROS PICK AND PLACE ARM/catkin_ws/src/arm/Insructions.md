## 221LIA001 - Robotics Lab 
### Course Project - Interim evaluation submission instructions

All batches have to commit the following to the batch project repo;
1. **catkin_package** of the project code submitted for interim evaluation.
2. **Gazebo ROS simulation video** of the project in _webm_ format
3. List of Websites/Github/StackOverflow/ROS answers referred while realizing the interim project submission.
For item 3 main ones would do but something like https://wiki.ros.org won't do you have to mention the actual page. For instance https://wiki.ros.org/ROS/Tutorials/CreatingPackage
