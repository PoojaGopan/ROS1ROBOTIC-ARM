[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/DqPwyK9C)
# 221LIA001 - Robotics Lab 
## Course Project - Interim evaluation submission

All batches have to commit the following to the batch project repo;
1. **catkin_package** of the project code submitted for interim evaluation.
2. **Gazebo ROS simulation video** of the project in _webm_ format
3. List of Websites/Github/StackOverflow/ROS answers referred while realizing the interim project submission.
For item 3 main ones would do but something like https://wiki.ros.org won't do you have to mention the actual page. For instance https://wiki.ros.org/ROS/Tutorials/CreatingPackage
